document.addEventListener('DOMContentLoaded', () => {
    console.log('Dashboard do Professor carregado.');
    // Adicione aqui funcionalidades para melhorar a interação do professor com a página.
});