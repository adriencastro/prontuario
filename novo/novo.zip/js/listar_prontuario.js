document.addEventListener('DOMContentLoaded', () => {
    console.log('Página de listagem de prontuários carregada.');
    // Adicione aqui funcionalidades adicionais, como filtros ou buscas dinâmicas.
});