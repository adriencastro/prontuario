document.addEventListener('DOMContentLoaded', () => {
    console.log('Dashboard do Aluno carregado.');
    // Adicione aqui funcionalidades para melhorar a interação do aluno com a página.
});